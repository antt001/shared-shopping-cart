import { Grid } from '@mantine/core';
import { CatalogItem } from './CatalogItem';


export function CatalogPage() {
  return (
    <Grid>
      <Grid.Col span={4}><CatalogItem /></Grid.Col>
      <Grid.Col span={4}><CatalogItem /></Grid.Col>
      <Grid.Col span={4}><CatalogItem /></Grid.Col>
    </Grid>
  );
}